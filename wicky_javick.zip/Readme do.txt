Free for commercial use

DO NOT SELL THIS FONT!!!

If you need more complete information you can contact me at:
bayuktx@gmail.com

to DONATE click here:
Paypal.me/bayuktx

Regards,
Bayuktx Studio