----

## Faculty Glyphic

Faculty Glyphic is a typeface that pays homage to London's rich history and spirit of innovation, taking cues from carved typography and the work of Bertholde Wolpe and Edward Johnston, it blends aspects of modernity and heritage. 

### License

Faculty Glyphic is licensed under the SIL Open Font License v1.1
